
// start listener
window.addEventListener ("pageshow", logListenerMain, true);


//listen to popup message to load log config
chrome.runtime.onMessage.addListener(ParsingDOM.loadConfig);


// listener for page load
async function logListenerMain (evt) {
  console.info("[Main] Starting listener 2.1...");
  
  //check if logrhythm web app
  if(!ParsingDOM.isLogRhyhthm()){
    throw new Error("[Main] Not LogRhythm dashboard.");
  }

  //ASYNC CACHING IS OFFICIALLY DISCONTINUED HENCE COMMENTED OUT CODE

  //var cache = new Cache(logPropLimit=logConfig.logCacheLimit, schemaPropLimit=logConfig.schemaCacheLimit);

  // var cache;
  // await CacheStorage.getCache().then(function(result) {
  //   console.info("[Main] Existing cache loaded.");
  //   cache = new Cache(cache=result);
  // }).catch(function (){
  //   console.info("[Main] No existing cache found. New cache created.");
  //   cache = new Cache();
  // });


  // if(cache && cache.logConfig){
  //   var logConfig = cache.logConfig;
  // }
  // else{
  //   try{
  //     let rawLogConfig = await ParsingProcessor.getLogConfig();
  //     var logConfig = new LogConfig(rawLogConfig);

  //     cache.setLogConfig(logConfig);
  //   }
  //   catch(err){
  //     console.error(`[Main] Error loading Log Config: "${err}".`);
  //     return;
  //   }
  // }

  // create cache
  // var cache = new Cache();
  // try{
  //   //load log_config.json
  //   let rawLogConfig = await ParsingProcessor.getLogConfig();
  //   var logConfig = new LogConfig(rawLogConfig);

  //   cache.setLogConfig(logConfig);
  // }
  // catch(err){
  //   console.error(`[Main] Error loading Log Config: "${err}".`);
  //   return;
  // }

  //loads LogConfig from cache
  //is saved from cache from file selection window
  var logConfig;
  await CacheStorage.getCache().then(function(result) {
    console.info("[Main] Existing Log Config found.");
    logConfig = result;
  }).catch(function (){
    console.info("[Main] No Log Config found. Stopping...");
  });

  //closes if log config has never been loaded
  if(logConfig == undefined) return;

  //saves LogConfig to cache
  //Cache I suppose is partly vestigial code - keep it as is, not laggy and don't wanna break things
  var cache = new Cache();
  cache.setLogConfig(logConfig);
  console.info("[Main] Log Config loaded.");

  
  //Cache.clearExpired(cache.logs, cache.schemas, logConfig.garbageCollectionInterval, cache.logProp, cache.schemaProp);

  //start garbage collection
  var intervalId = window.setInterval(Cache.clearExpired, logConfig.garbageCollectionInterval, cache.logs, cache.schemas, logConfig.garbageCollectionInterval, cache.logProp, cache.schemaProp);
  console.info("[Main] Garbage collection started.");


  //obtain the element for log message tab
  var inspector = ParsingDOM.getLogElement();
  if(inspector == undefined){
    return;
  }

  //obtain the element for inserting parsed log
  var div = await ParsingDOM.getFormattedElement(inspector);


  //looking for changes(mutations) in log message tab
  const callback = (mutationArr, observer) => {
    for(let i = 0; i < mutationArr.length; i++){
      if(mutationArr[i].type == "characterData"){

        //get raw log
        let rawLog = mutationArr[0].target.textContent;

        //retrieve formatted version from cache -> returns undefined if not found
        var formatted = cache.getValue(rawLog, "log");
        
        //if above is undefined (log has yet to be parsed)
        try{
          parse:if(formatted == undefined){
            //get correct filter according to raw log (using criteria rules from logConfig)
            let filter = ParsingProcessor.getFilter(rawLog, logConfig);

            //break if no filter for log (no criteria rules matched with log) -> will skip to formatted == undefined below
            if(!filter) break parse;
            
            //get the schema -> could already be in cache -> could create new schema based on parsing rules from the filter
            //schema is needed to convert raw log to parsed object
            let schema = ParsingInterpreter.getSchema(filter.parsingRules, cache);
            
            //using the schema create the formatted log
            formatted = ParsingInterpreter.runSchema(rawLog, schema);
            
            //sometimes the schema can return a string (due to byp function) and not an object
            //this will check and convert the object into a string according to the format, e.g., json, xml
            if(typeof formatted == "object") formatted = ParsingFormatter.formatObj(formatted, filter.format);
            
            //basically if parsing failed break -> will skip to formatted == undefined below
            if(formatted == undefined || formatted == null) break parse;
            
            //cache formatted log
            cache.setValue(rawLog, formatted, "log");

            // if(cache != null && typeof cache == 'object'){
            //   cache.setValue(rawLog, formatted, "log");
            //   CacheStorage.setCache(cache); //might be slow;
            // }
          }
        }
        catch(err){
          //display errors that may have occurred
          formatted = `Failed to format log: "${err}".`;
          console.error(`[Main] ${formatted}`);
        }      
        
        if(formatted == undefined || formatted == null) {
          //display typically when there are no parsing/criteria rules
          formatted = 'Failed to format log: "missing parsing rules".';
          console.error(`[Main] ${formatted}`);
        }

        //finally add the formatted log to the webpage
        div.innerHTML = formatted;
      }
    }
  };

  //start looking for changes in log message tab
  const listenerConfig = { characterData: true, attributes: false, childList: true, subtree: true };
  const observer = new MutationObserver(callback);
  observer.observe(inspector, listenerConfig);
}
