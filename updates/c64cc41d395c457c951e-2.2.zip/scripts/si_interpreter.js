
//these functions are specified in the parsing rules
//they are used to turn the raw log into an object (except for byp which turns it into a formatted string)
class ParsingFunctions{
    //short for regex
    static reg(source, regex, firstIndex, lastIndex){
        if(typeof source === "string") return ParsingFunctions.#regString(source, regex, firstIndex, lastIndex);
        if(Array.isArray(source)) return ParsingFunctions.#regArray(source, regex, firstIndex, lastIndex);
        return source;
    }

    //regex for string input
    static #regString(source, regex, firstIndex, lastIndex){
        const regexp = new RegExp(regex, 'gms');
        var matches = source.match(regexp);
        if(matches != null && firstIndex != undefined && lastIndex != undefined){
            return ParsingFunctions.#regIndex(matches, firstIndex, lastIndex);
        }
        return matches;   
    }

    //regex for array input - only outputs 1d arrays
    static #regArray(source, regex, firstIndex, lastIndex){
        source = source.slice(0);

        var arr = [];
        for(var i = 0; i < source.length; i++){
            let matches = ParsingFunctions.#regString(source[i], regex, firstIndex, lastIndex);
            if(matches != null){
                arr.push(...matches);
            }
        }
        return arr;
    }

    //implements range arguments in reg functions
    static #regIndex(matches, firstIndex, lastIndex){
        firstIndex = Number(firstIndex);
        lastIndex = Number(lastIndex);
        if(firstIndex < 0) firstIndex + matches.length;
        if(lastIndex < 0) lastIndex + matches.length;
        firstIndex = LogConfig.clamp(firstIndex, 0, matches.length - 1);
        lastIndex = LogConfig.clamp(lastIndex, 0, matches.length - 1);
        if(firstIndex > lastIndex){
            let temp = firstIndex;
            firstIndex = lastIndex;
            lastIndex = temp;
        }
        return matches.slice(firstIndex, lastIndex + 1);
    }

    //short for convert -> treats inputted strings/arrays of strings as either json or xml to turn into an object
    static con(source, type){
        if(typeof source === "string") return ParsingFunctions.#conString(source, type);
        if(Array.isArray(source)) return ParsingFunctions.#conArray(source, type);
        return source;
    }

    //con for string
    static #conString(source, type){
        switch(type){
            case "json":{
                return ParsingFunctions.#conJson(source);
            }
            case "xml":{
                return ParsingFunctions.#conXML(source);
            }
        }
    }

    //con for array
    static #conArray(source, type){
        source = source.slice(0);

        var arr = [];
        
        switch(type){
            case "json":{
                var func = ParsingFunctions.#conJson;
                break;
            }
            case "xml":{
                var func = ParsingFunctions.#conXML;
                break;
            }
        }

        for(let i = 0; i < source.length; i++){
            arr.push(func(source[i]));
        }

        return arr;
    }

    //con for json type
    static #conJson(source){
        if(ParsingFormatter.isJson(source)){
            var formatted = ParsingFormatter.clean(source, 'json');
            try{
                var obj = JSON.parse(formatted);
            }
            catch(e){
                var obj = JSON.parse(source);
            }
            return obj;
        }
        return source;
    }

    //con for xml type
    static #conXML(source){
        var formatted = ParsingFormatter.clean(source, 'xml');
        if(ParsingFormatter.isXML(formatted)){
            var parser = new DOMParser();
            var xmlDoc = parser.parseFromString(formatted,"text/xml");
            var root = xmlDoc.children[0];
            var obj = {
                "xml": ParsingFunctions.#conXMLObj(root)
            };
            return obj;
        }
        return source;
    }

    //con for xml type -> extra parsing code
    static #conXMLObj(element)
    {   
        var obj = {};
      
        var attr = element.attributes;
        if(attr.length > 0){
            obj['_attributes_'] = {};
            for(let i = 0; i < attr.length; i++){
                obj['_attributes_'][attr[i].name] = attr[i].value;
            }
        }
        
        var text = "";
        for(let i = 0; i < element.childNodes.length; i++){
            if(element.childNodes[i].nodeName == "#text"){
                text += element.childNodes[i].nodeValue.trim();
            }
        }

        if(text.length > 0) obj['_text_'] = text;

        var children = element.children;
        if(children.length > 0){
            for(let i = 0; i < children.length; i++){
                let childTag = children[i];
                let tagName = childTag.tagName;
                if(tagName in obj){
                    tagName = ParsingFunctions.#saltKey(tagName);
                }
                obj[tagName] = ParsingFunctions.#conXMLObj(childTag);
            }
        }
        return obj;
    }

    //short for key-value pair -> takes array of keys and arrays and creates an object
    static kvp(keys, values, join=false){
        if(keys == null || values == null)
            throw new Error('[ParsingFunctions][kvp] Argument arrays cannot be null');
        if(!join && keys.length != values.length)
            throw new Error(`[ParsingFunctions][kvp] Argument arrays must be the same length for join=false. Keys(${keys.length}) != Values(${values.length})`);

        var length = keys.length;
        if(join && keys.length > values.length) 
            length = values.length;

        var obj = {};

        for(var i = 0; i < length; i++){
            let key = keys[i];
            if(key in obj){
                key = ParsingFunctions.#saltKey(key);
            }
            obj[key] = values[i];
        }

        return obj;  
    }

    //used for when keys are identical and need to be differentiated 
    static #saltKey(key){
        return `${key}____copy${Math.floor(Math.random() * 1000000)+1000000}`;
    }

    //short for bypass - skips conversion to object and goes straight to the formatted log -> typically only for xml
    //why? going from xml -> obj -> xml(formatted) is slower than xml -> xml(formatted)
    static byp(source, type){
        if(typeof source != "string") throw new Error(`[ParsingFunctions][byp] Argument must be string. Type passed: ${typeof source}`);
        switch(type){
            case "json":{
                return ParsingFunctions.#bypJson(source);
            }
            case "xml":{
                return ParsingFunctions.#bypXML(source);
            }
        }
        return source;
    }

    //byp json -> extra code for adding syntax highlighting
    static #bypJson(source){
        if(ParsingFormatter.isJson(source)){
            var json = ParsingFormatter.clean(source, 'json');
            json = JSON.stringify(JSON.parse(json), undefined, 4);
            json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
                var cls = 'json_number';
                if (/^"/.test(match)) {
                    if (/:$/.test(match)) {
                        cls = 'json_key';
                    } else {
                        cls = 'json_string';
                    }
                } else if (/true|false/.test(match)) {
                    cls = 'json_boolean';
                } else if (/null/.test(match)) {
                    cls = 'json_null';
                }
                return '<span class="' + cls + '">' + match + '</span>';
            });
        }
        return source;
    }

    //byp for xml
    static #bypXML(source){
        var formatted = ParsingFormatter.clean(source, 'xml');
        if(ParsingFormatter.isXML(formatted)){
            var parser = new DOMParser();
            var xmlDoc = parser.parseFromString(formatted,"text/xml");
            var root = xmlDoc.children[0];
            var txt = "";
            return ParsingFunctions.#bypXMLSyntax(root, txt, 0);
        }
        return source;
    }

    //byp xml -> extra code for adding syntax highlighting
    static #bypXMLSyntax(element, txt, indent){
        var indentSpace = " ".repeat(indent);
        var indentIncrement = 6;

        txt += `\n${indentSpace}&lt;<span class="xml_tag_name">${element.tagName}</span>`;
      
        var attr = element.attributes;
        for(var j = 0; j < attr.length; j++){
          txt += ` <span class="xml_attr_name">${attr[j].name}</span>=<span class="xml_attr_value">'${attr[j].value}'</span>`;
        }
      
        txt += '&gt;';
      
        for(var j = 0; j < element.children.length; j++){
          txt = ParsingFunctions.#bypXMLSyntax(element.children[j], txt, indent + indentIncrement);
        }
      
        for(var j = 0; j < element.childNodes.length; j++){
          if(element.childNodes[j].nodeName == "#text"){
            txt += `<span class="xml_tag_value">${element.childNodes[j].nodeValue.trim()}</span>`;
          }
        }
      
        if(element.children.length > 0){
          txt += `\n${indentSpace}`;
        }
      
        if(element.lastChild){
          txt += `&lt;/<span class="xml_tag_name">${element.tagName}</span>&gt;`;
        }
      
        return txt;
      }

    //short for trim -> removes surrounding white spaces
    static trm(source){
        if(typeof source === "string") return source.trim();
        if(Array.isArray(source)){
            source = source.slice(0);
            for(let i = 0; i < source.length; i++) source[i] = source[i].trim();
        }
        return source;
      }

      //short for split -> converts string to array based on character 
      static spl(source, value){
        if(typeof source === "string") return source.split(value);
        if(Array.isArray(source)){
            source = source.slice(0);
            for(let i = 0; i < source.length; i++) source[i] = source[i].split(value);
        }
        return source;
      }

      //short for lowercase -> converts strings to only lowercase
      static low(source){
        if(typeof source === "string") return source.toLowerCase();
        if(Array.isArray(source)){
            source = source.slice(0);
            for(let i = 0; i < source.length; i++) source[i] = source[i].toLowerCase();
        }
        return source;
      }

      //short for uppercase -> converts strings to only uppercase
      static upp(source){
        if(typeof source === "string") return source.toUpperCase();
        if(Array.isArray(source)){
            source = source.slice(0);
            for(let i = 0; i < source.length; i++) source[i] = source[i].toUpperCase();
        }
        return source;
      }

      //short for replace -> replaces substring with another substring according to pattern
      static rep(source, searchValue, replaceValue){
        if(typeof source === "string") return source.replace(searchValue, replaceValue);
        if(Array.isArray(source)){
            source = source.slice(0);
            for(let i = 0; i < source.length; i++) source[i] = source[i].replace(searchValue, replaceValue);
        }
        return source;
      }

      //short for slice -> extracts range of elements in array
      static sli(source, startIndex, endIndex){
        if(!Array.isArray(source)) throw new Error(`[ParsingFunctions][sli] Source must be an array. Source type: ${typeof source}.`);
        
        if(startIndex == undefined) startIndex = 0;
        else startIndex = Number(startIndex);

        if(endIndex == undefined) endIndex = source.length;
        else endIndex = Number(endIndex);

        return source.slice(startIndex, endIndex);
      }
}

//mainly for created and executing schema
//schema are objects that contain the executable parsing rules to be applied to the raw log
//these will create objects (or strings with byp function)
class ParsingInterpreter{

    //either creates schema from raw parsing rules
    //or gets existing schema from cache
    static getSchema(rules, cache=null){

        if(cache != null && typeof cache == 'object'){
            var schema = cache.getValue(rules.toString(), "schema");
            if(schema != undefined) return schema;
        }
        var schema = {
            "variables":{},
            "rules":[]
        }
        
        for(let i = 0; i < rules.length; i++){
            let obj = {};
            
            //let rul = ParsingInterpreter.cleanRule(rules[i]);
            let rul = rules[i];
            let sections = rul.split(/->+(?=(?:(?:[^']*'){2})*[^']*$)/g);
            obj.source = sections[0].split(/;+(?=(?:(?:[^']*'){2})*[^']*$)/g);

            let funcName = sections[1].trim();
            obj.function = funcName;

            //obj.param = sections[1].match(/(?<=[a-z]{3}:|;)[^;']+|(?<=')([^']*)(?=')/g);

            obj.output = sections[2].split(/;+(?=(?:(?:[^']*'){2})*[^']*$)/g);

            //if('_out' in obj.output && funcName != "byp") throw new Error("[ParsingInterpreter] Cannot output to '_out'; only children of '_out'.");
            schema.rules.push(obj);
        }
        
        if(cache != null && typeof cache == 'object'){
            cache.setValue(rules.toString(), schema, "schema");
            //CacheStorage.setCache(cache);
        }

        return schema;
    }

    //executes the schema to create an object (or string for byp)
    //schema.variables stores the variables used in the execution of the schema -> view it like another other variable in an interpreted language
    //_src is a reserved variable that stores raw log
    //_out is a reserved variable that will store completed formatted object/string - this is what is returned
    //schema.rules contains the executable rules (in the presentation i called them instruction blocks i think) -> these are the instructions that tell the extension how to parse the log
    static runSchema(source, schema, formatter){
        if(typeof source === 'object' && !Array.isArray(source) && source !== null) return {};
        schema.variables._src = source;
        schema.variables._out = {};
        schema.variables._ftr = formatter;

        for(let i = 0; i < schema.rules.length; i++){
            schema = this.#runRule(schema.rules[i], schema);
        }
        //onsole.log(schema.variables);
        return schema.variables._out;
    }

    //executes rule from schema
    static #runRule(rule, schema){
        var values = this.#getSourceVariables(rule.source, schema.variables);

        if(rule.function != 'asn'){
            var func = this.#getFunction(rule.function);
            values = func.apply(this, values);
        }
        schema.variables = this.#assign(values, rule.output[0], schema.variables);
        return schema;
    }

    //used for updating variables in schema.variables
    static #assign(source, output, variables){
        var obj = variables;
        let keys = output.match(/(?<=\.|^)(.*?)(?=\.|$)/g);
        for(let j = 0; j < keys.length - 1; j++){
            let k = keys[j];
            if(!(k in obj)){
                obj[k] = {};
            }
            obj = obj[k];
        }
        if(typeof source == "string") obj = this.#assignString(source, obj, keys[keys.length - 1]);
        if(Array.isArray(source)) obj = this.#assignArray(source, obj, keys[keys.length - 1]);
        if(typeof source === 'object' && source !== null) obj = this.#assignObject(source, obj, keys[keys.length - 1]);
 
        return variables;        
    }

    //updating variable with a string
    static #assignString(source, obj, key){
        obj[key] = source;
        return obj;
    }

    //updating variable with an array
    static #assignArray(source, obj, key){
        obj[key] = source;
        return obj;
    }

    //updating variable with an object
    static #assignObject(source, obj, key){
        if(!(key in obj)) obj[key] = {};
        for (const [k, v] of Object.entries(source)) {
            obj[key][k] = v;
        }
        return obj;
    }

    //used for getting values stored in schema.variables
    static #getSourceVariables(names, variables){
        for(let i = 0; i < names.length; i++){
            if(names[i].startsWith("'") && names[i].endsWith("'")){
                names[i] = names[i].substring(1, names[i].length - 1);
                continue;
            }

            var obj = variables;
            let keys = names[i].match(/(?<=\.|^)(.*?)(?=\.|$)/g);
            for(let j = 0; j < keys.length; j++){
                let k = keys[j];
                if(k in obj){
                    obj = obj[k];
                }
                else{
                    obj = null;
                    break;
                }
            }
            names[i] = obj;
        }
        return names;
    }

    // static cleanRule(rule){
    //     rule = rule.replace(/\\\\/g, '\\');
    //     return rule;
    // }

    //used for converting function name to actual executable function (from the ParsingFunctions class)
    static #getFunction(name){
        switch(name){
            case "reg":{
                return ParsingFunctions.reg;
            }
            case "con":{
                return ParsingFunctions.con;
            }
            case "kvp":{
                return ParsingFunctions.kvp;
            }
            case "byp":{
                return ParsingFunctions.byp;
            }
            case "trm":{
                return ParsingFunctions.trm;
            }
            case "spl":{
                return ParsingFunctions.spl;
            }
            case "upp":{
                return ParsingFunctions.upp;
            }
            case "low":{
                return ParsingFunctions.low;
            }
            case "rep":{
                return ParsingFunctions.rep;
            }
            case "sli":{
                return ParsingFunctions.sli;
            }
            default:{
                return null;
            }
        }
    }
}