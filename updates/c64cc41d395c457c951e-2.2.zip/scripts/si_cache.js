//used for non-volatile cache storage and retrieval
class CacheStorage{
    //retrieves value from cache
    static async getCache(){
        var key = 'logFormatter';
        return new Promise((resolve, reject) => {
            chrome.storage.local.get([key], function (result) {
                if (result[key] === undefined) {
                reject();
                } else {
                resolve(result[key]);
                }
            });
        });
    }

    //sets value in cache
    static async setCache(cache){
        chrome.storage.local.set({'logFormatter': cache}).then(() => {
            return true;
          });
        return false;
    }

}

//used for volatile cache storage and retrieval
class Cache{
    logs = {};
    schemas = {};
    logConfig;

    logProp = {
        "limit": 200,
        "size": 0
    };
    
    schemaProp = {
        "limit": 100,
        "size": 0
    };

    constructor(logPropLimit=200, schemaPropLimit=100, cache=undefined){
        if(typeof cache == 'object'){
            this.logs = cache.logs;
            this.schemas = cache.schemas;

            this.logProp = cache.logProp;

            this.schemaProp = cache.schemaProp;

            this.logConfig = cache.logConfig;

            Cache.resetTime(this.logProp, this.schemaProp);
            return;
        }
        this.logProp.limit = logPropLimit;
        this.schemaProp.limit = schemaPropLimit;
    }

    //adds logconfig to cache
    //updates values in cache according to logconfig
    setLogConfig(logConfig){
        this.logConfig = logConfig;

        for(let i = 0; i < this.logProp.limit - logConfig.logCacheLimitMax; i++){
            this.delValue(this.logs, this.logProp);
        }

        for(let i = 0; i < this.schemaProp.limit - logConfig.schemaCacheLimitMax; i++){
            this.delValue(this.schemas, this.schemaProp);
        }

        this.logProp.limit = logConfig.logCacheLimitMax;
        this.schemaProp.limit = logConfig.schemaCacheLimitMax;
    }

    //retrieves value from cache
    getValue(key, type){
        if(typeof key != 'string') throw new TypeError(`Key must be string. Argument type: ${typeof key}`);
        switch(type){
            case "log":{
                var obj = this.logs;
                break;
            }
            case "schema":{
                var obj = this.schemas;
                break;
            }
            default:{
                return undefined;
            }
        }

        var hash = Cache.getHash(key);
        if(hash in obj){
            obj[hash]['time'] = Date.now();
            var rtn = obj[hash]['value'];
            if(typeof rtn == 'object') rtn = structuredClone(rtn);
            return rtn;
        }
        return undefined;
    }

    //sets value in cache
    setValue(key, value, type){
        if(typeof key != 'string') throw new TypeError(`Key must be string. Argument type: ${typeof key}`);
        switch(type){
            case "log":{
                var obj = this.logs;
                var prop = this.logProp;
                break;
            }
            case "schema":{
                var obj = this.schemas;
                var prop = this.schemaProp;
                break;
            }
            default:{
                return undefined;
            }
        }

        if(prop.size >= prop.limit) this.delValue(obj, prop);
        var hash = Cache.getHash(key);
        if(typeof value == 'object') value = structuredClone(value);
        obj[hash] = {'time': Date.now(), 'value': value};
        prop.size++;
    }

    //pops value from cache
    delValue(obj, prop){

        var oldest = null;
        var time = Number.MAX_VALUE;
        for(const [key, value] of Object.entries(obj)){
            if(value['time'] < time){
                oldest = key;
                time = value['time'];
            }
        }
        if(oldest == null) return;
        delete obj[oldest];
        prop.size--;
    }

    //calculates hash from string - used for comparisons
    static getHash(string){
        var hash = 0;
        for (var i = 0; i < string.length; i++) {
            var code = string.charCodeAt(i);
            hash = ((hash<<5)-hash)+code;
            hash = hash & hash; // Convert to 32bit integer
        }
        return hash;
    }

    //removes expired values in cache
    static clearExpired(logs, schemas, expiredDecrement, logProp, schemaProp){
        var cmp = Date.now() - expiredDecrement + 1;
        var logCount = 0;
        for(const [key, value] of Object.entries(logs)){
            if(value['time'] <= cmp){
                logCount++;
                delete logs[key];
                logProp.size--;
            }
        }

        var schemaCount = 0;
        for(const [key, value] of Object.entries(schemas)){
            if(value['time'] <= cmp){
                schemaCount++;
                delete schemas[key];
                schemaProp.size--;
            }
        }

        if(logCount > 0 || schemaCount > 0) console.info(`[Garbage Collection] Removed ${logCount} expired log(s) and ${schemaCount} expired scheme(s).`);
    }

    //resets expiration time for values in cache
    static resetTime(logs, schemas){
        var now = Date.now();
        for(const key of Object.keys(logs)){
            logs[key]['time'] += now;
        }

        for(const key of Object.keys(schemas)){
            schemas[key]['time'] += now;
        }

    }
}