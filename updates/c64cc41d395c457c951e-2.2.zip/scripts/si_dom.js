//contains functions for getting/setting elements in DOM
class ParsingDOM{
    static JSON_CSS_PATH = "/css/si_json.css";
    static XML_CSS_PATH = "/css/si_xml.css";

    //checks if webpage is logrhythm
    static isLogRhyhthm(){
        try{
            return document.documentElement.attributes.item(0).value === "Analyze";
        }
        catch(err){
            return false;
        }
    }

    //gets log message tab element
    static getLogElement(){
        return document.querySelector("div[class='detailsActionsScroll details-log-message ng-binding']");
    }

    //obsolete - gets elements for fields in events and actions tab
    static getFieldElements(){
        return document.querySelectorAll("[ng-repeat='common in selected.common'], tr[ng-repeat='(prop, val) in selected.directional']");
    }

    //gets element for inserting formatted log
    //creates element if not found - this also includes injecting the necessary css
    static async getFormattedElement(inspector){
        var div = document.getElementById("si-log-format");
        
        if(div == undefined){
            div = document.createElement("div");
            div.id = "si-log-format";
            inspector.appendChild(div);
            
            await ParsingDOM.getStyleSheetElement(ParsingDOM.JSON_CSS_PATH);
            console.info(`[DOM] Injected style sheet: '${ParsingDOM.JSON_CSS_PATH}'.`);
 
            await ParsingDOM.getStyleSheetElement(ParsingDOM.XML_CSS_PATH);
            console.info(`[DOM] Injected style sheet: '${ParsingDOM.XML_CSS_PATH}'.`);
        }

        console.info("[DOM] Created element: 'si-log-format'.");

        return div;
    }

    //injects css for formatted log
    static async getStyleSheetElement(path){
        var element=document.createElement("input");
        element;
        element.rel="stylesheet";
        element.href=await chrome.runtime.getURL(path);
        return element;
    }
    
    //loads config from file explorer
    static async loadConfig(message, sender, sendResponse){
        //downloads file
        //parsing it into object
        //creates LogConfig object
        //caches it (for refreshed page to access)
        //refreshes page
        if(message.type = "load"){
            try{
                var logConfig = new LogConfig(message.json);
                CacheStorage.setCache(logConfig);
                console.info("[DOM] Successfully imported Log Config.")
                ParsingDOM.refresh();
            }
            catch(err){
                console.error(`[DOM] Error loading Log Config: "${err}".`);
                chrome.runtime.sendMessage({
                    type: "failure", 
                });
                return;
            }
        }
    }
    
    //creates input element
    static createInputWindow(){
        var element = document.createElement("input");
        element.id="si-select-1";
        element.accept=".json";
        element.type="file";
        document.getElementById("ui-blocker").appendChild(element);
        return element;
    }
    
    //sends message to background (service worker) to refresh page - where the refreshed page will load new log config
    static refresh() {
        chrome.runtime.sendMessage({message:"refresh"}, function(response) {
            if(response.status === "200"){
                console.info(`[DOM] ${response.message}.`);
            }
            else if(response.status === "500"){
                console.error(`[DOM] ${response.message}.`);
            }
        });
    }  
}