//clear cache
function clear(){
    chrome.storage.local.clear(); 
    chrome.storage.sync.clear(); 
}

//reloads page
function reload(){
    chrome.runtime.reload();
}

//sends request to background to download the inputted url
function downloadFile(){
    var el = document.getElementById("si-readfile-1");
    chrome.runtime.sendMessage({message:"download", url:el.value});
}

function inputFeedback(request, sender, sendResponse) {
    if (request.type === "success") {
        var el = document.getElementById("si-readfile-1");
        el.value = null;
        el.setAttribute("placeholder", "Successfully imported");
    }
    else if(request.type === "failure"){
        var el = document.getElementById("si-readfile-1");
        el.value = null;
        el.setAttribute("placeholder", "Failed to import");
    }
}

document.getElementById("si-clear-1").onclick = function() {clear()};
document.getElementById("si-reload-1").onclick = function() {reload()};
document.getElementById("si-downloadfile-1").onclick = function() {downloadFile()};
chrome.runtime.onMessage.addListener(inputFeedback);