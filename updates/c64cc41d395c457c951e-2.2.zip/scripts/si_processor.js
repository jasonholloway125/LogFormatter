
//object used to store data from log_config.json
class LogConfig{
    static logCacheLimitMax = 1000;
    static schemaCacheLimitMax = 1000;
    static garbageCollectionIntervalMax = 3600000;

    constructor(object){
        this.object = object;
        this.filters = object.filters;
        this.criteriaArray = [];
        this.rulesArray = [];
        this.formatArray = [];

        this.logCacheLimit = LogConfig.clamp(object.logCacheLimit, 0, LogConfig.logCacheLimitMax);
        this.schemaCacheLimit = LogConfig.clamp(object.schemaCacheLimit, 0, LogConfig.schemaCacheLimitMax);
        this.garbageCollectionInterval = LogConfig.clamp(object.garbageCollectionInterval, 0, LogConfig.garbageCollectionIntervalMax);

        for(let i = 0; i < this.filters.length; i++){
            let criterion = this.#validateCriteriaRule(this.filters[i].criteriaRules);
            this.criteriaArray.push(criterion);

            let parsingRule = this.#validateParsingRule(this.filters[i].parsingRules)
            this.rulesArray.push(parsingRule);

            let format = this.#validateFormat(this.filters[i].format)
            this.formatArray.push(format);
        }
    }

    //ensure values are between min and max
    static clamp(value, min, max){
        if(typeof value != 'number') throw new TypeError(`[LogConfig] Invalid value; must be number. Actual type: '${typeof value}'`);
        if(value > max) return max;
        else if(value < min) return 0;
        return value;
    }

    //check if the criteria rules in log_config.json are valid
    #validateCriteriaRule(arr){
        if(!Array.isArray(arr)) throw new TypeError(`[LogConfig] Invalid Criteria Rule: 'is not an array'`);

        for(let i = 0; i < arr.length; i++){
            if(!Array.isArray(arr[i])) throw new TypeError(`[LogConfig] Invalid Criteria Rule: 'is not nested array'`);
            for(let j = 0; j < arr[i].length; j++){
                let obj = arr[i][j];
                if(!(typeof obj == 'object' && obj != null && !Array.isArray(obj) && obj.regex != undefined)) {
                    throw new TypeError(`[LogConfig] Invalid Criteria Rule: 'Index: [${i}][${j}]'`);
                }

                if(obj.caseInsensitive){
                    obj.regex = obj.regex.toLowerCase();
                }
            }
        }

        return arr;
    }

    //check if the parsing rules in log_config.json are valid
    #validateParsingRule(arr){
        if(!Array.isArray(arr)) throw new TypeError(`[LogConfig] Invalid Parsing Rule: 'not an array'`);

        var regex = RegExp(/->\w{3}->[_\w\.]+$/, 'gms');

        for(let i = 0; i < arr.length; i++){
            if(typeof arr[i] != 'string' || arr[i].match(regex) == null) {
                throw new TypeError(`[LogConfig] Invalid Parsing Rule: '${arr[i]}'`);
            }
        }

        return arr;
    }

    //check if the formats in log_config.json are valid
    #validateFormat(str){
        if(typeof str != 'string' || !ParsingFormatter.isValidFormat(str)){
            throw new TypeError(`[LogConfig] Invalid Format: '"${str}" is not valid'`);
        }

        return str.toLowerCase();
    }
}

//used to retrieve the correct filter for the raw log according to the criteria rules in log_config.json
//also retrieves log_config.json
class ParsingProcessor{
    static LOG_SOURCES_CONFIG_PATH = '/config/log_config.json';

    //retrieve log_config.json
    static async getLogConfig(){
        try{
            var lsConfigURL = await chrome.runtime.getURL(ParsingProcessor.LOG_SOURCES_CONFIG_PATH);
        
            return fetch(lsConfigURL)
            .then(function(response)
            {
                return response.json();
            });
        }
        catch(err){
            console.error(`[ParsingProcessor] Could not retrieve Log Config file: '${err}'`);
        }
    }

    //find correct filter using criteria rules against raw log
    static getFilter(source, logConfig){
        var sourceObj = {
            "caseSensitive": source,
            "caseInsensitive": source.toLowerCase()
        }

        for(let i = 0; i < logConfig.criteriaArray.length; i++){
            if(ParsingProcessor.#criteriaRules(sourceObj, logConfig.criteriaArray[i])){
                return logConfig.filters[i];
            }
        }
    }

    //iterate through criteria rules of each filter - return correct filter
    static #criteriaRules(sourceObj, criteriaRules){
        for(let i = 0; i < criteriaRules.length; i++){
            let j = 0;
            while(j < criteriaRules[i].length && 
                ParsingProcessor.#matchRegex(sourceObj, criteriaRules[i][j].regex, criteriaRules[i][j].condition, criteriaRules[i][j].caseInsensitive)){
                    j++;
                }
            
            if(j == criteriaRules[i].length) return true;
        }
        return false;
    }

    //check if crtieria rule is a match
    static #matchRegex(sourceObj, regexStr, condition, caseInsensitive){
        var source = sourceObj.caseSensitive;
        if(caseInsensitive) source = sourceObj.caseInsensitive;

        var regex = RegExp(regexStr, "gms");
        var matches = source.match(regex);

        if(matches != null && matches.length > 0){
            if(condition) return ParsingProcessor.#testCondition(matches.length, condition);
            return true;
        }

        return false;
    }

    //check if condition from criteria rule is a match
    static #testCondition(matchFreq, source){
        var condition = ParsingProcessor.#getCondition(source);

        switch(condition.operator){
            case '<':{
                return matchFreq < condition.value;
            }
            case '>':{
                return matchFreq > condition.value;
            }
            case '=':{
                return matchFreq == condition.value;
            }
            default:{
                return false;
            }
        }
    }

    //parse condition
    static #getCondition(source){
        var condition = {};

        let condMatch = source.match(/^(\=|<|>)/gms);
        if(condMatch == null) throw new TypeError(`[ParsingProcessor] Invalid condition; invalid conditional operator in '${source}'`);
        condition.operator = condMatch[0];
        
        let valueMatch = source.match(/(?<=^(\=|<|>))(.*?)$/gms);
        try{
            let value = Number(valueMatch[0]);
            condition.value = value;
        }
        catch(err){
            if(valueMatch.length != 1) throw new TypeError(`[ParsingProcessor] Invalid condition; invalid value in '${source}'`);
        }

        return condition;
    }
}