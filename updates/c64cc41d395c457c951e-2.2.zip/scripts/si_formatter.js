//contains functions related to converting obj to string or formatting strings

class ParsingFormatter{
    //used for replacing characters that break the parsing process
    static cleanReplacements = {
        "json":[
            [/\\|(?<=}|\]|\))"|"(?={|\[|\()/gms, '']
        ],
        "xml":[
            [/\?xml/g, 'xml'],
            [/\?>/g, '/>'],
            [/&/g, '&amp;'],
            [/<value not set>/g, 'value not set'],
            [/<never>/g, 'never'],
        ]
    }

    //checks if the input is a json string
    static isJson(source) {
        if(source == undefined){
            return false;
        }
        let value = typeof source !== "string" ? JSON.stringify(source) : source;    
        try {
            value = JSON.parse(value);
        } catch (e) {
            return false;
        }
        return typeof value === "object" && value !== null;
    }


    //checks if the input is an xml string
    static isXML(source){
        try{
            new DOMParser().parseFromString(source,"text/xml");
            return true;
        }
        catch(e){
            return false;
        }
    }

    //applies cleanReplacements to replace bad characters
    static clean(source, type){
        if(!(type in ParsingFormatter.cleanReplacements)) throw new TypeError(`Invalid Type '${type}'. Valid options: 'json', 'xml'.`);

        var cleaned = source;
        var replacements = ParsingFormatter.cleanReplacements[type];

        for(let i = 0; i < replacements.length; i++){
            cleaned = cleaned.replace(replacements[i][0], replacements[i][1]);
        }

        return cleaned;
    }

    //checks if input is a valid format, e.g., json, xml
    static isValidFormat(format){
        return format in ParsingFormatter.cleanReplacements;
    }

    //converts object to respective string type
    static formatObj(obj, type){
        switch(type){
            case "json":{
                return this.#formatJson(obj);
            }
            case "xml":{
                return this.#formatXML("root", obj, 0, false);
            }
            default:{
                throw new Error(`Invalid Format Type: ${type}.\nAccepted types: 'json', 'xml'.`);
            }
        }
    }

    //converts object to json string
    static #formatJson(obj){
        var json = JSON.stringify(obj, undefined, 4);
        //json = json.replace(/____copy\d*$/g, "");
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
            var cls = 'json_number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'json_key';
                } else {
                    cls = 'json_string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'json_boolean';
            } else if (/null/.test(match)) {
                cls = 'json_null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    }

    //converts object to xml string
    static #formatXML(tagName, value, indent, newLineStart=true){
        var indentSpace = " ".repeat(indent);
        var indentIncrement = 6;
        var txt = "";
        var nl = (newLineStart) ? '\n' : '';
        tagName = `<span class="xml_tag_name">${tagName}</span>`;

        if(Array.isArray(value)){
            let array = "";
            for(let i = 0; i < value.length; i++){                
                array += ParsingFormatter.#formatXML("element", value[i], indent + indentIncrement);
            }
            txt += `${nl}${indentSpace}&lt;${tagName}&gt;${array}\n${indentSpace}&lt;/${tagName}&gt;`;
        }
        else if(typeof value === "object" && value != null){
            var wValue = { ...value };

            let attributes = "";
            if("_attributes_" in wValue){
                for (const [k, v] of Object.entries(wValue['_attributes_'])){
                    attributes += ` <span class="xml_attr_name">${k}</span>=<span class="xml_attr_value">&quot;${v}&quot;</span>`;
                }
                delete wValue['_attributes_']; 
            }
            let text = "";
            if("_text_" in wValue){
                text += `<span class="xml_tag_value">${wValue["_text_"]}</span>`;
                delete wValue['_text_'];
            }

            let children = "";
            let childrenEntries = Object.entries(wValue);
            if(childrenEntries.length > 0){
                for (let [k, v] of childrenEntries){
                    k = k.replace(/____copy\d*$/, "");
                    children += ParsingFormatter.#formatXML(k, v, indent + indentIncrement);
                }
            }

            let newlineClose = ((children.length > 0) ? `\n${indentSpace}` : '');

            txt += `${nl}${indentSpace}&lt;${tagName}${attributes}&gt;${children}${text}${newlineClose}&lt;/${tagName}&gt;`;
        }
        else{
            let valueStr = `<span class="xml_tag_value">${value.toString()}</span>`;
            txt += `${nl}${indentSpace}&lt;${tagName}&gt;${valueStr}&lt;/${tagName}&gt;`;
        }

        return txt;
    }
}

